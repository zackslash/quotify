package main

import (
	"time"

	"github.com/zackslash/fortifi-inspiration"
)

const (
	intervalPeriod time.Duration = 24 * time.Hour

	// post inspiration image at 10:30 AM each day
	hour   int = 10
	minute int = 30
	second int = 00
)

type jobTicker struct {
	t *time.Timer
}

func main() {
	jt := newJobTicker()
	for {
		<-jt.t.C
		jt.updateJobTicker()
	}
}

func getNextTickDuration() time.Duration {
	now := time.Now()
	nextTick := time.Date(now.Year(), now.Month(), now.Day(), hour, minute, second, 0, time.Local)
	if nextTick.Before(now) {
		nextTick = nextTick.Add(intervalPeriod)
	}
	return nextTick.Sub(time.Now())
}

func newJobTicker() jobTicker {
	return jobTicker{time.NewTimer(getNextTickDuration())}
}

func (jt jobTicker) updateJobTicker() {
	inspiration.PerformInspiration()
	jt.t.Reset(getNextTickDuration())
}
