//go:generate $GOPATH/src/github.com/zackslash/quotify/generate.sh

// File for `go generate``

package quotify
